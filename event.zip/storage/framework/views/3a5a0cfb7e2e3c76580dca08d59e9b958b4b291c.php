

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Penjualan Tiket
        <small> <strong><?php echo e($event->nama_event); ?></strong></small>
    </h1>
    <ol class="breadcrumb" style="padding-right: 100px;">
        <a href="<?php echo e(route('tiket')); ?>/tambah/event/<?php echo e($event->id); ?>">
            <button class="btn btn-primary">
                <i class="fa fa-tags"></i> Tambahkan Penjualan Tiket
            </button>
        </a>
    </ol>
    <br />
</section>
<?php if(session('status')): ?>
<script>
    swal("success!", "<?php echo session('status'); ?>", "success");
</script>
<?php endif; ?>
<!-- Main content -->
<section class="content">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
    <div class="table-responsive">
        <div class="box">
            <table id="example" class="table table-striped table-bordered table-hover display">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Peserta</th>
                        <th>Asal</th>
                        <th>Jenis Tiket</th>
                        <th>Tanggal Input</th>
                        <th>-</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($t->nama_peserta); ?></td>
                        <td><?php echo e($t->asal); ?></td>
                        <td><?php echo e($t->nama_tiket); ?></td>
                        <td><?php echo e($t->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('tiket')); ?>/<?php echo e($t->id); ?>">
                                <span class="label label-info">
                                    <i class="fa fa-folder-open-o"></i> View detail
                                </span>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <br/>
    <a href="<?php echo e(route('agen_index')); ?>">
        <button class="btn btn-default">
            <i class="fa fa-arrow-circle-o-left"></i> Kembali ke dashboard
        </button>
    </a>
</section><!-- /.content -->

<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agen.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/agen/tiket/event.blade.php ENDPATH**/ ?>