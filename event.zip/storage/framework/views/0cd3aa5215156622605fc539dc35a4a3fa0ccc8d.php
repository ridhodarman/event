

<?php $__env->startSection('content'); ?>
<div class="panel-heading">
  <h3 class="panel-title">
    <a href="javascript:void(0);" class="toggle-sidebar">
      <span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span>
    </a> Dashboard
  </h3>
</div>
<div class="panel-body">
  welcome
</div><!-- panel body -->

<script>
  $("#dashboard").css("font-weight", "bolder");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/admin/index.blade.php ENDPATH**/ ?>