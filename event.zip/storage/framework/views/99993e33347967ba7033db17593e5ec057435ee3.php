

<?php $__env->startSection('content'); ?>
<div class="panel-heading">
    <h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar"><span class="fa fa-angle-double-left"
                data-toggle="offcanvas" title="Maximize Panel"></span></a> Riwayat Penjualan Tiket</h3>
</div>
<div class="panel-body">
    <div class="table-responsive">
        <table id="example" class="table table-striped table-bordered table-hover display" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Peserta</th>
                    <th>Event</th>
                    <th>Jenis Tiket</th>
                    <th>Tanggal Input</th>
                    <th>Agen</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($t->nama_peserta); ?></td>
                    <td><?php echo e($t->nama_event); ?></td>
                    <td><?php echo e($t->nama_tiket); ?></td>
                    <td><?php echo e($t->created_at); ?></td>
                    <td><?php echo e($t->name); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><!-- panel body -->

<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });

    $("#tiket").css("font-weight", "bolder");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/admin/tiket/index.blade.php ENDPATH**/ ?>