

<?php $__env->startSection('content'); ?>
<div class="panel-heading">
  <h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar"><span class="fa fa-angle-double-left"
        data-toggle="offcanvas" title="Maximize Panel"></span></a> Dashboard</h3>
</div>
<div class="panel-body">
  <div class="table-responsive">
    <table id="example" class="table table-striped table-bordered table-hover display" style="width:100%">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama</th>
          <th>Email</th>
          <th>Waktu Register</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($u->name); ?></td>
          <td><?php echo e($u->email); ?></td>
          <td><?php echo e($u->created_at); ?></td>
          <td>
            <?php if($u->role == 99): ?>
            <span class="label label-danger">Admin</span>
            <?php endif; ?>
            <?php if($u->agen): ?>
            <span class="label label-success">Agen</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div><!-- panel body -->

<script>
  $(document).ready(function () {
      $('#example').DataTable();
  });
  
  $("#tab-user").click();
  $("#user_register").css("font-weight", "bolder");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/admin/user/index.blade.php ENDPATH**/ ?>