

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<script src="<?php echo e(URL::asset('agen_page/jquery.min.js')); ?>" type="text/javascript"></script>
<section class="content-header">
    <h1>
        Penjualan Tiket
        <small></small>
    </h1>
    <ol class="breadcrumb" style="padding-right: 100px;">
        
    </ol>
    <br />
</section>
<?php if(session('status')): ?>
<script>
    swal("success!", "<?php echo session('status'); ?>", "success");
</script>
<?php elseif(session('hapus')): ?>
<script>
    swal("<?php echo session('hapus'); ?>");
</script>
<?php endif; ?>
<!-- Main content -->
<section class="content">
    <div class="table-responsive">
        <div class="box">
            <table id="example" class="table table-striped table-bordered table-hover display">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Event</th>
                        <th>Tanggal Pelaksanaan</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($e->nama_event); ?></td>
                        <td><?php echo e($e->tanggal_mulai); ?></td>
                        <td>
                            <a href="<?php echo e(route('tiket')); ?>/event/<?php echo e($e->id); ?>">
                                <span class="label label-success">
                                    <i class="fa fa-fw fa-ticket"></i> Lihat Penjualan Tiket
                                </span>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <br/>
    <a href="<?php echo e(route('agen_index')); ?>">
        <button class="btn btn-default">
            <i class="fa fa-arrow-circle-o-left"></i> Kembali ke dashboard
        </button>
    </a>
</section><!-- /.content -->

<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agen.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/agen/tiket/penjualan.blade.php ENDPATH**/ ?>