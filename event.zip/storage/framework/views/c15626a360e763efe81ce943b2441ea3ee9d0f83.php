

<?php $__env->startSection('content'); ?>
<div class="panel-heading">
    <h3 class="panel-title">
        <a href="javascript:void(0);" class="toggle-sidebar">
            <span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span>
        </a> Event
    </h3>
</div>
<div class="panel-body">

    <?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo session('status'); ?>

    </div>
    <?php elseif(session('hapus')): ?>
    <div class="alert alert-warning alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo session('hapus'); ?> Atau coba cek tong sampah
    </div>
    <?php endif; ?>
    <div style="float: right;">
        <a href="<?php echo e(route('event')); ?>/tambah">
            <button type="button" class="btn btn-default">
                <i class="glyphicon glyphicon-list"></i> Tambah Event
            </button>
        </a>
    </div>
    <h4 class="font-weight-bold mb-0">Daftar Event</h4>

    <div class="table-responsive">
        <table id="example" class="table table-striped table-bordered table-hover display" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Tanggal mulai event</th>
                    <th>-</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($e->nama_event); ?></td>
                    <td><?php echo e($e->tanggal_mulai); ?></td>
                    <td>
                        <a href="<?php echo e(route('event')); ?>/<?php echo e($e->id); ?>">
                            <button class="btn btn-primary btn-xs">
                                <i class="glyphicon glyphicon-new-window"></i> detail
                            </button>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div><!-- panel body -->

<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });

    $("#event").css("font-weight", "bolder");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/admin/event/index.blade.php ENDPATH**/ ?>