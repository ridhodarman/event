

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
    Dashboard
    <small>agen panel</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Dashboard</li>
  </ol>
</section>

<!-- Main content -->
<section class="content">
  <label><u> Event akan datang </u></label>
  <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <ul class="timeline">
    <!-- END timeline item -->
    <!-- timeline time label -->
    <li class="time-label">
      <span class="bg-gray">
        <?php echo e($e->tanggal_mulai); ?>

      </span>
    </li>
    <!-- /.timeline-label -->
    <!-- timeline item -->
    <li>
      <?php
      
      $tgl = date('Y-m-d');
      $tgl1 = new DateTime($e->tanggal_mulai);
      $tgl2 = new DateTime($tgl);
      $hari = $tgl2->diff($tgl1)->days;
      ?>
      <i class="fa fa-camera bg-purple"></i>
      <div class="timeline-item">
        <span class="time"><i class="fa fa-clock-o"></i><?php echo e($hari); ?> hari lagi</span>
        <h3 class="timeline-header"><a href="javascript:;"><?php echo e($e->nama_event); ?></a> .</h3>
        <div class="timeline-body">
          <img src="<?php echo e(URL::asset('assets/150x100.png')); ?>" data-original="<?php echo e(URL::asset('foto/brosur/'.$e->foto_brosur)); ?>"
            class="lazy" width="100px" onclick="window.open(`<?php echo e(URL::asset('foto/brosur/'.$e->foto_brosur)); ?>`)" style="cursor: pointer;">
          <?php echo e(substr($e->deskripsi,0,200)); ?>... <a href="<?php echo e(route('index')); ?>/show/<?php echo e($e->id); ?>" target="_blank">Readmore</a><br /> <br />
          <a href="<?php echo e(route('tiket')); ?>/event/<?php echo e($e->id); ?>">
            <button class="btn btn-success"><i class="fa fa-fw fa-ticket"></i> Klik disini untuk penjualan
              tiket</button>
          </a>
        </div>
      </div>
    </li>
    <!-- END timeline item -->
    <li>
      <i class="fa fa-clock-o bg-gray"></i>
      </>
  </ul>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php
  if ( count($event)==0 ) {
  echo "tidak ada event dalam waktu dekat";
  }
  ?>
  <br />

  <?php $__currentLoopData = $agen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($a->no_whatsapp): ?>

  <?php else: ?>
  <script src="<?php echo e(URL::asset('agen_page/jquery.min.js')); ?>" type="text/javascript"></script>
  <div class="modal fade" id="exampleModal-profil" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
              aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Lengkapi Profil</h4>
        </div>
        <div class="modal-body">
          <p> Sepertinya anda belum meng-inputkan Nomor WhatsApp anda. Silahkan lengkapi profil anda dahulu </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Nanti Saja</button>
          <a href="<?php echo e(route('profil')); ?>">
            <button type="button" class="btn btn-primary" >Edit Profil Sekarang</button>
          </a>
        </div>
      </div><!-- /.modal-content -->
    </div>
  </div>
  <script>
    $(document).ready(function () {
      $('#exampleModal-profil').modal('show');
    });
  </script>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section><!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agen.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/agen/index.blade.php ENDPATH**/ ?>