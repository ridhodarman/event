

<?php $__env->startSection('content'); ?>
<div class="panel-heading">
  <h3 class="panel-title"><a href="javascript:void(0);" class="toggle-sidebar"><span class="fa fa-angle-double-left" data-toggle="offcanvas" title="Maximize Panel"></span></a> Agen User</h3>
</div>
<div class="panel-body">
  <div class="table-responsive">
    <table id="example" class="table table-striped table-bordered table-hover display" style="width:100%">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama</th>
          <th>Email</th>
          <th>No. Whatsapp</th>
          <th>-</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $agen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($a->name); ?></td>
          <td><?php echo e($a->email); ?></td>
          <td><?php echo e($a->no_whatsapp); ?></td>
          <td>
            <!-- Button trigger modal -->
<button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#exampleModal<?php echo e($a->id); ?>">
  <i class="glyphicon glyphicon-remove-circle"></i> Remove
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal<?php echo e($a->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Yakin Hapus?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Apakah anda yakin hapus <?php echo e($a->name); ?> (email: <?php echo e($a->email); ?>) sebagai agen ?
      </div>
      <div class="modal-footer">
        <form action="<?php echo e(route('agen')); ?>/<?php echo e($a->id); ?>" method="POST" class="d-inline" style="float: left">
          <?php echo method_field('delete'); ?>
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger" id="tombol-hapus">
              yes, remove it
          </button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        </form>
      </div>
    </div>
  </div>
</div>
            
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <hr/>
  <form class="forms-sample" action="<?php echo e(route('agen')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <h5>Tambahkan Agen:</h5>
    <label>Pilih akun:</label>
    <select class="js-example-basic-single <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
        id="user_id" name="user_id">
        <option></option>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($u->id); ?>"><?php echo e($u->name); ?> (<?php echo e($u->email); ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <div style="float: right;"></div>
        <button type="submit" class="btn btn-primary mr-2">Tambah</button>
    </div>
    <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger alert-dismissable">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <?php echo e($message); ?> atau coba cek tong sarok di database
    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</form>
<?php if(session('status')): ?>
  <script>
      swal("success!", "<?php echo session('status'); ?>", "success");
  </script>
<?php endif; ?>


</div><!-- panel body -->

<script>
  $(document).ready(function () {
      $('#example').DataTable();
  });

  $(document).ready(function() {
    $('.js-example-basic-single').select2();
  });

  $( "#tab-user" ).click();
  $("#agen").css("font-weight", "bolder");
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/admin/agen/index.blade.php ENDPATH**/ ?>