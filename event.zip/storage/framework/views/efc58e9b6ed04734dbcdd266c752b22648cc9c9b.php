

<?php $__env->startSection('content'); ?>
<script src="<?php echo e(URL::asset('agen_page/jquery.min.js')); ?>" type="text/javascript"></script>
<!-- Content Header (Page header) -->
<section class="content-header">
    <ol class="breadcrumb" style="padding-right: 100px;">
        <a href="<?php echo e(route('tiket')); ?>/event/<?php echo e($tiket->event_id); ?>">
            <button class="btn btn-default">
                <i class="fa fa-tags"></i> Kembali ke daftar penjualan tiket
            </button>
        </a>
    </ol>
    <h1>
        Tiket
        <small>Kode: <strong><?php echo e($tiket->kode_tiket); ?></strong></small>
    </h1>
    <br />
</section>
<?php if(session('status')): ?>
<script>
    swal("success!", "<?php echo session('status'); ?>", "success");
</script>
<?php endif; ?>
<!-- Main content -->
<section class="content">
    <diV class="row">
        <div class="col-sm-6">
            <div class="table-responsive">
                <div class="box">
                    <table id="example" class="table table-hover display">
                        <tbody>

                            <tr>
                                <td>Nama Peserta:</td>
                                <td><?php echo e($tiket->nama_peserta); ?></td>
                            </tr>
                            <tr>
                                <td>Asal:</td>
                                <td><?php echo e($tiket->asal); ?></td>
                            </tr>
                            <tr>
                                <td>No Whatsapp:</td>
                                <td> <?php if($tiket->no_wa): ?> +62 <?php endif; ?>
                                    <?php echo e($tiket->no_wa); ?>

                                </td>
                            </tr>
                            <tr>
                                <td>E-mail:</td>
                                <td><?php echo e($tiket->e_mail); ?></td>
                            </tr>
                            <tr>
                                <td>Event:</td>
                                <td><?php echo e($tiket->nama_event); ?></td>
                            </tr>
                            <tr>
                                <td>Tiket:</td>
                                <td><?php echo e($tiket->nama_tiket); ?></td>
                            </tr>
                            <tr>
                                <td>Keterangan:</td>
                                <td><?php echo e($tiket->keterangan); ?></td>
                            </tr>
                            <tr>
                                <td>Dibuat Pada:</td>
                                <td><?php echo e($tiket->created_at); ?>

                            </tr>
                            </tr>
                            <tr>
                                <td>Terakhir Diubah:</td>
                                <td><?php echo e($tiket->updated_at); ?>

                            </tr>
                            </tr>

                        </tbody>
                    </table>

                    <button class="btn btn-app" data-toggle="modal" data-target="#exampleModal-hapus"
                        style="color: red;">
                        <i class="fa fa-trash"></i> Hapus
                    </button>
                    <div class="modal fade" id="exampleModal-hapus" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                            aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title">Hapus Tiket</h4>
                                </div>
                                <div class="modal-body">
                                    Yakin hapus tiket ini?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                    &emsp;
                                    <form action="" method="POST" class="d-inline" style="float: right">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger">Hapus Sekarang</button>
                                    </form>
                                </div>
                            </div><!-- /.modal-content -->
                        </div>
                    </div>

                    <button class="btn btn-app" data-toggle="modal" data-target="#exampleModal-edit"
                        style="color: darkblue;">
                        <i class="fa fa-edit"></i> Edit
                    </button>
                    <div class="modal fade" id="exampleModal-edit" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <form action="" method="POST">
                                <?php echo method_field('patch'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"
                                            aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Edit Tiket</h4>
                                    </div>
                                    <div class="modal-body">
                                        <label>Nama Peserta</label>
                                        <input type="text" class="form-control" name="nama_peserta"
                                            value="<?php echo e($tiket->nama_peserta); ?>" />
                                        <?php $__errorArgs = ['nama_peserta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                        <script>$(document).ready(function () { $('#exampleModal-edit').modal('show'); });</script>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <br />
                                        <label>Jenis Tiket</label>
                                        <select class="form-control" id="jenis" name="jenis_tiket">
                                            <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($j->id); ?>"><?php echo e($j->nama_tiket); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <br />
                                        <label>Asal</label>
                                        <input type="text" class="form-control" name="asal"
                                            value="<?php echo e(old('asal', $tiket->asal)); ?>" />
                                        <?php $__errorArgs = ['asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                        <script>$(document).ready(function () { $('#exampleModal-edit').modal('show'); });</script>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <br />
                                        <div class="form-group">
                                            <label>No. Whatsapp</label>
                                            <div class="input-group">
                                                <span class="input-group-addon">+62</span>
                                                <input type="text" class="form-control" placeholder="8xxxxxxx"
                                                    name="no_wa"
                                                    class="form-control <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    value="<?php echo e(old('no_wa', $tiket->no_wa)); ?>" />
                                            </div>
                                            <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger">
                                                <?php echo e($message); ?>

                                            </div>
                                            <script>$(document).ready(function () { $('#exampleModal-edit').modal('show'); });</script>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-group">
                                            <label>E-mail</label>
                                            <input type="text" class="form-control" placeholder="" name="e_mail"
                                                class="form-control <?php $__errorArgs = ['e_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                value="<?php echo e(old('e_mail', $tiket->e_mail)); ?>" />
                                            <?php $__errorArgs = ['e_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger">
                                                <?php echo e($message); ?>

                                            </div>
                                            <script>$(document).ready(function () { $('#exampleModal-edit').modal('show'); });</script>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <br />
                                        <label>Keterangan</label>
                                        <textarea class="form-control"
                                            name="keterangan"><?php echo e($tiket->keterangan); ?></textarea>
                                        <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger">
                                            <?php echo e($message); ?>

                                        </div>
                                        <script>$(document).ready(function () { $('#exampleModal-edit').modal('show'); });</script>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default"
                                            data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </div><!-- /.modal-content -->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        $link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") .
        "://$_SERVER[HTTP_HOST]"."/kode_tiket/".$tiket->kode_tiket;
        $link = base64_encode($link);
        $n = base64_encode($tiket->nama_peserta);
        $a = base64_encode($tiket->asal);
        //$w = base64_encode($tiket->no_wa);
        $e = base64_encode($tiket->email);
        $k = base64_encode($tiket->kode_tiket);
        $f = base64_encode($tiket->foto_tiket);

        try {
        $w = base64_encode( "+62".substr($tiket->no_wa, 0, -3)."***" );
        }
        catch (Exception $e) {
        $w = base64_encode( $tiket->no_wa );
        }

        try {
        $email = explode("@", $tiket->e_mail);
        $e = substr($email[0], 0, -3)."***";
        $e = base64_encode( $e."@".$email[1] );
        }
        catch (Exception $e) {
        $e = base64_encode( $tiket->e_mail );
        }
        ?>
        <div class="col-sm-6">
            <a class="btn btn-social btn-github" href="<?php echo e(route('index')); ?>/print2.php?
link=<?php echo e($link); ?>&
n=<?php echo e($n); ?>&
a=<?php echo e($a); ?>&
w=<?php echo e($w); ?>&
e=<?php echo e($e); ?>&
k=<?php echo e($k); ?>&
f=<?php echo e($f); ?>&
                    " target="_blank">
                <i class="fa fa-barcode"></i> Print Tiket
            </a>
            <br /><br />
            <button type="button" class="btn btn-social btn-google-plus" data-toggle="modal"
                data-target="#exampleModal-e">
                <i class="fa fa-envelope"></i> Kirim tiket via E-mail
            </button>
            <div class="modal fade" id="exampleModal-e" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Kirim tiket via E-mail</h4>
                        </div>
                        <form action="<?php echo e(url('/sendTiket')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="modal-body">
                                E-mail:
                                <input type="text" class="form-control" placeholder="masukkan email peserta ..."
                                    value="<?php echo e($tiket->e_mail); ?>" name="email"/>
                                <input type="" name="nama" value="<?php echo e($tiket->nama_peserta); ?>">
                                <input type="" name="event" value="<?php echo e($tiket->nama_event); ?>">
                                <input type="" name="kode" value="<?php echo e($tiket->kode_tiket); ?>">
                                <input type="" name="link" value="<?php echo e(route('index')); ?>/print2.php?
link=<?php echo e($link); ?>&
n=<?php echo e($n); ?>&
a=<?php echo e($a); ?>&
w=<?php echo e($w); ?>&
e=<?php echo e($e); ?>&
k=<?php echo e($k); ?>&
f=<?php echo e($f); ?>&">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Kirim</button>
                            </div>
                        </form>
                    </div><!-- /.modal-content -->
                </div>
            </div>
            <br /><br />
            <button type="button" class="btn btn-social btn-success" data-toggle="modal" data-target="#exampleModal-wa">
                <i class="fa fa-whatsapp"></i> Kirim via WhatsApp
            </button>
            <div class="modal fade" id="exampleModal-wa" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Kirim tiket via WhatsApp</h4>
                        </div>
                        <div class="modal-body">
                            <label> Masukkan nomor WhatsApp </label>
                            <div class="input-group">
                                <span class="input-group-addon">+62</span>
                                <input type="text" class="form-control" placeholder="8xxxxxxx" id="no_wa"
                                    value="<?php echo e($tiket->no_wa); ?>">
                            </div>
                            <br />
                            <label> Pesan </label>
                            <textarea class="form-control" id="pesan_wa">
Hi <?php echo e($tiket->nama_peserta); ?>. 
Kode tiket anda adalah: <?php echo e($tiket->kode_tiket); ?> .
                            </textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" onclick="kirim_wa()"
                                data-dismiss="modal">Kirim</button>
                        </div>
                    </div><!-- /.modal-content -->
                </div>
            </div>
        </div>
    </diV>
</section><!-- /.content -->


<section class="main-section">
    <!-- Add Your Content Inside -->
    <div class="content">
        <!-- Remove This Before You Start -->
        <?php if(\Session::has('alert-failed')): ?>
        <div class="alert alert-failed">
            <div><?php echo e(Session::get('alert-failed')); ?></div>
        </div>
        <?php endif; ?>
        <?php if(\Session::has('alert-success')): ?>
        <div class="alert alert-success">
            <div><?php echo e(Session::get('alert-success')); ?></div>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(url('/sendEmail')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email">
            </div>
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" id="name" name="nama" />
            </div>
            <div class="form-group">
                <label for="judul">Judul:</label>
                <input type="text" class="form-control" id="judul" name="judul" />
            </div>
            <div class="form-group">
                <label for="pesan">Pesan:</label>
                <textarea class="form-control" id="pesan" name="pesan"></textarea>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-md btn-primary">Send Email</button>
            </div>
        </form>
    </div>
    <!-- /.content -->
</section>


<?php
echo '
<script>
    let jenis = '.$tiket->jenis.'
</script>
'
?>

<script>

    function kirim_wa() {
        let nomor = document.getElementById("no_wa").value;
        let pesan = document.getElementById("pesan_wa").value;
        window.open(`https://api.whatsapp.com/send?phone=62${nomor}&text=${pesan}`);
    }

    $(document).ready(function () {
        $("#jenis").val(jenis);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agen.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/agen/tiket/show.blade.php ENDPATH**/ ?>