

<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Penjualan Tiket
        <small> <strong></strong></small>
    </h1>
    <!-- <ol class="breadcrumb" style="padding-right: 100px;">
        <a href="<?php echo e(route('tiket')); ?>/tambah/event/<?php echo e($event->id); ?>">
            <button class="btn btn-primary">
                <i class="fa fa-tags"></i> Tambahkan Penjualan Tiket
            </button>
        </a>
    </ol>
    <br/> -->
</section>

<!-- Main content -->
<section class="content">
    <div class="box box-success">
        <div class="box-header">
            <h3 class="box-title"><?php echo e($event->nama_event); ?></h3>
        </div><!-- /.box-header -->
        <div class="box-body">
            <form role="form" method="POST">
                <?php echo csrf_field(); ?>
                <!-- text input -->
                <div class="form-group">
                    <label>Nama Peserta</label>
                    <input type="text" placeholder="nama lengkap peserta seminar/event..."
                        name="nama_peserta" class="form-control <?php $__errorArgs = ['nama_peserta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('nama_peserta')); ?>"/>
                    <?php $__errorArgs = ['nama_peserta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label>Asal Instansi / Lokasi</label>
                    <input type="text" class="form-control"
                        placeholder="nama instansi/ kampus atau lokasi asal peserta ..." 
                        name="asal" class="form-control <?php $__errorArgs = ['asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('asal')); ?>"/>
                    <?php $__errorArgs = ['asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label>No. Whatsapp</label>
                    <div class="input-group">
                        <span class="input-group-addon">+62</span>
                        <input type="text" class="form-control" placeholder="8xxxxxxx" 
                        name="no_wa" class="form-control <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('no_wa')); ?>"/>
                    </div>
                    <?php $__errorArgs = ['no_wa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label>E-mail</label>
                    <input type="text" class="form-control"
                        placeholder="" 
                        name="e_mail" class="form-control <?php $__errorArgs = ['e_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('e_mail')); ?>"/>
                    <?php $__errorArgs = ['e_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- radio --><br />
                <div class="form-group">
                    <label>Pilih Tiket</label>
                    <?php $__currentLoopData = $jenis_tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="radio">
                        <button type="button" class="btn btn-secondary btn-xs" data-toggle="modal"
                            data-target="#exampleModal<?php echo e($j->id); ?>"
                            title="klik untuk menampilkan info tiket: <?php echo e($j->nama_tiket); ?>">
                            <i class="fa fa-info"></i>
                        </button>
                        <label>
                            <input type="radio" name="jenis_tiket" id="optionsRadios1" value="<?php echo e($j->id); ?>">
                            <?php echo e($j->nama_tiket); ?>


                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal<?php echo e($j->id); ?>" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title"><?php echo e($j->nama_tiket); ?></h4>
                                        </div>
                                        <div class="modal-body">
                                            <?php $paragraphs = explode(PHP_EOL, $j->keterangan); ?>
                                            <?php $__currentLoopData = $paragraphs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p><?php echo e($paragraph); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <strong>Harga:</strong>
                                            <p>Rp. <?php echo e($j->harga); ?></p>
                                            <a href="<?php echo e(URL::asset('foto/tiket/'.$j->foto_tiket)); ?>" target="_blank">
                                                view tiket <i class="fa fa-unlink"></i>
                                            </a>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default"
                                                data-dismiss="modal">Close</button>
                                        </div>
                                    </div><!-- /.modal-content -->
                                </div>
                            </div>
                        </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__errorArgs = ['jenis_tiket'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- textarea -->
                <div class="form-group">
                    <label>Keterangan</label>
                    <textarea class="form-control" rows="3"
                        placeholder="*opsional, isikan catatan bila perlu. Jika tidak ada kosongkan bagian ini ..."
                        class="form-control <?php $__errorArgs = ['asal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="keterangan"><?php echo e(old('keterangan')); ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary pull-right">
                    <i class="fa fa-tags"></i> Submit
                </button>
                <br /><br />
            </form>
        </div><!-- /.box-body -->
    </div><!-- /.box -->
</section><!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('agen.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\event\resources\views/agen/tiket/tambah.blade.php ENDPATH**/ ?>